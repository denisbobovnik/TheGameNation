nonzero1.0 by nodethirtythree design
http://www.nodethirtythree.com

**********************************************************************************
NOTE: The actual template and all its color schemes are in the 'nonzero_actual'
subfolder. Don't use the files in this folder as they're only meant to be used for
demonstration purposes.
**********************************************************************************

This template is released under the Creative Commons Attributions 2.5 license, which
basically means you can do whatever you want with it provided you credit the author.
(ie. me). In the case of this template, a link back to my site is more than sufficient.

If you want to read the license, go here:

http://creativecommons.org/licenses/by/2.5/

If you're sufficiently intoxicated, or just like a good mental beating, you can also
read the full legal code here:

http://creativecommons.org/licenses/by/2.5/legalcode

- enks


